from myMilePackage.mileConverter import to_yard
from myMilePackage.mileConverter import to_feet