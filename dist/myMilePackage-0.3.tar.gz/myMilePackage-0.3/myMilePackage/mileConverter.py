MILE_TO_YARD = 1760
MILE_TO_FEET = 5280

def to_yard(val):
    return val * MILE_TO_YARD

def to_feet(val):
    return val * MILE_TO_FEET